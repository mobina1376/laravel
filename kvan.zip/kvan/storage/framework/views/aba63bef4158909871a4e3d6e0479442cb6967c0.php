<!doctype html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>


  
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/bootstrap.min.css')); ?>" type="text/css">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.6/css/mdb.min.css" rel="stylesheet">


    <link href="<?php echo e(asset('css/admin/style.css')); ?>" rel="stylesheet" type="text/css">


</head>
<body>

<nav class="navbar  navbar-light bg-gradiant-green-blue nav-shadow">

    <a class="navbar-brand" href="#"></a>
    <span class="">
            

            
                <a class="text-decoration-none px-3 text-dark" href="#"><i class="fas fa-comments"></i>

               <span class="badge badge-danger"></a>
            <span class="dropdown">
                <a class="dropdown-toggle text-decoration-none text-dark" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-user"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">logout</a>
                </div>
            </span>
       </span>
</nav>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block pt-3 bg-sidebar sidebar px-0">
            <a class="text-decoration-none d-block py-1 px-2 mt-1" href="#"><i class="fas fa-home"></i> Home</a>
            <a class="text-decoration-none d-block py-1 px-2 mt-1" href="#"><i class="fas fa-clipboard-list"></i> Category</a>
            <a class="text-decoration-none d-block py-1 px-2 mt-1" href="#"><i class="fas fa-newspaper"></i> Article</a>
            <a class="text-decoration-none d-block py-1 px-2 mt-1" href="#"><i class="fas fa-comments"></i> Comment</a>
            <a class="text-decoration-none d-block py-1 px-2 mt-1" href="#"><i class="fas fa-bars"></i> Menus</a>
            <a class="text-decoration-none d-block py-1 px-2 mt-1" href="#"><i class="fas fa-users"></i> User</a>
            <a class="text-decoration-none d-block py-1 px-2 mt-1" href="#"><i class="fas fa-tools"></i> Web Setting</a>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">


                <section class="pt-3 pb-1 mb-2 border-bottom">
        <h1 class="h5">Edit Menu</h1>
    </section>

<section class="row my-3">
    <section class="col-12">
        <?php
        echo $post;
        print_r($post);
        echo $post[0];
        // var_dump($post);
        echo "salam";
        ?>
        <form method="Post" 
        
        >
         
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
           
            <div class="form-group">
                <label for="name">title</label>
                <input type="text" class="form-control" id="name" name="title"  value="<?php echo e($post->title); ?>">
            </div>

            <div class="form-group">
                <label for="url">body</label>
                <input type="text" class="form-control" id="url" name="body" value="<?php echo e($post->body); ?>">
            </div>

            <button type="submit" class="btn btn-primary btn-sm">update</button>
        </form>
    </section>
</section>



        </main>
    </div>
</div>



</main>
</div>
</div>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
<!--<script>window.jQuery || document.write('<script src="/docs/4.3/assets/js/vendor/jquery-slim.min.js"><\/script>')</script><script src="/docs/4.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GLT1Kqob5UDEML61gCyjnAcfMXgkdP3wGcg45" crossorigin="anonymous"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.9.0/feather.min.js"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>-->
<!--<script src="dashboard.js"></script>-->

<script src="http://localhost:4499/admin-panel/public/js/admin/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script src="http://localhost:4499/admin-panel/public/js/admin/mdb.min.js"></script>
</body>
</html><?php /**PATH C:\Users\MahiGoli\Desktop\kvan\resources\views/Post/edit.blade.php ENDPATH**/ ?>